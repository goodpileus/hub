A Pen created at CodePen.io. You can find this one at https://codepen.io/lnfnunes/pen/mEkzBa.

 https://developer.mozilla.org/en-US/docs/Web/API/Battery_Status_API

Check API browsers support: caniuse.com/#search=BatteryManager